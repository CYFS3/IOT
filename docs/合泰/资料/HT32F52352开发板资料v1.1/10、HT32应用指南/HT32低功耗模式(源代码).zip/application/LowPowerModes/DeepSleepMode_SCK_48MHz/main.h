/*********************************************************************************************************//**
 * @file    LowPowerModes/DeepSleepMode/main.h
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   The header file of Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32F5XXXX_MAIN_H
#define __HT32F5XXXX_MAIN_H



#ifdef __cplusplus
 extern "C" {
#endif

/* Exported types ------------------- -----------------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------------------------------------*/

//#define DEEP_SLEEP_1
#define DEEP_SLEEP_2

#define LOOP_50mS
//#define LOOP_500mS
//#define LOOP_1S
//#define LOOP_3S
//#define LOOP_5S

/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* __HT32F5XXXX_MAIN_H */
