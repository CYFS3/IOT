/*********************************************************************************************************//**
 * @file    LowPowerModes/DeepSleepMode/main.c
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "main.h"

/** @addtogroup HT32F5xxxx_Application_Notes HT32F5xxxx Application Notes
  * @{
  */

/** @addtogroup LowPowerModes Low power modes
  * @{
  */

/** @addtogroup DeepSleepMode Deep Sleep Mode
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/* Private define ------------------------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
uint32_t wCntTmp = 0;
uint16_t hADCR;

/* Private function prototypes -----------------------------------------------------------------------------*/
void ADC_Configuration(void);
void BAK_Configuration(void);
void GPIO_Configuration(void);

/* Private functions ---------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{

#if (HT32F_LIB_DEBUG == 1)
  debug();
#endif

  /* Backup domain relate configuration */
  BAK_Configuration();

  /* GPIO relate configuration */
  GPIO_Configuration();

  /* ADC relate configuration */
  ADC_Configuration();

  while (1)
  {
    /* Disable ADC engine */
    ADC_Cmd(HT_ADC, DISABLE);

    /* Read to clear WUP flags */
    while(HT_GPIOB->DINR & GPIO_PIN_12);
    while(PWRCU_GetFlagStatus() & PWRCU_FLAG_WUP);

    /* Waits until the value of RTC counter synchronous, the wCntTmp is readed at wakeup.
       After wakeup from deepsleep mode,
       the RTC_CNT register synchronous at next rising edge of CK_RTC */
#ifndef SLEEP
    while(RTC_GetCounter() == wCntTmp);
#endif

    /* Read to clear RTC flags */
    RTC_GetFlagStatus();

#ifdef LOOP_50mS
    RTC_SetCompare(RTC_GetCounter()+ 205);
#endif

#ifdef LOOP_500mS
    RTC_SetCompare(RTC_GetCounter()+ 2048);
#endif

#ifdef LOOP_1S
    RTC_SetCompare(RTC_GetCounter()+ 4096);
#endif

#ifdef LOOP_3S
    RTC_SetCompare(RTC_GetCounter()+ 12288);
#endif

#ifdef LOOP_5S
    RTC_SetCompare(RTC_GetCounter()+ 20480);
#endif

    /* Read to clear RTCOUT Level mode flag */
    RTC_GetOutStatus();
    HT_GPIOA->RR = GPIO_PIN_5;

#ifdef DEEP_SLEEP_1
    PWRCU_DeepSleep1(PWRCU_SLEEP_ENTRY_WFE);
#endif

#ifdef DEEP_SLEEP_2
    PWRCU_DeepSleep2(PWRCU_SLEEP_ENTRY_WFE);
#endif

    /* PA5 output high */
    HT_GPIOA->SRR = GPIO_PIN_5;

    /* Store value of RTC_CNT at wakeup */
    wCntTmp = RTC_GetCounter();

    /* Enable ADC engine */
    ADC_Cmd(HT_ADC, ENABLE);
    ADC_SoftwareStartConvCmd(HT_ADC, ENABLE);
    while (ADC_GetFlagStatus(HT_ADC, ADC_INT_SINGLE_EOC) == RESET);
    ADC_SoftwareStartConvCmd(HT_ADC, DISABLE);
    ADC_ClearIntPendingBit(HT_ADC, ADC_INT_SINGLE_EOC);
    hADCR = (HT_ADC->DR[0]&0x0FFF);
  }
}

/*********************************************************************************************************//**
 * @brief Configures the RTC.
 * @retval None
 ************************************************************************************************************/
void BAK_Configuration(void)
{
  /* Enable RTC PCLK and waits until it's can be access */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.BKP          = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
  if(PWRCU_CheckReadyAccessed() != PWRCU_OK)
  {
    while(1);
  }

  /* Configure Low Speed External clock (LSI) */
  RTC_LSILoadTrimData();
  while(CKCU_GetClockReadyStatus(CKCU_FLAG_LSIRDY) == RESET);

  RTC_ClockSourceConfig(RTC_SRC_LSI);

  /* Configure the RTC */
  RTC_ClockSourceConfig(RTC_SRC_LSI) ;
  RTC_SetPrescaler(RTC_RPRE_8);
  RTC_WakeupConfig(RTC_WAKEUP_CM, ENABLE);
  RTC_OutConfig(RTC_ROWM_LEVEL, RTC_ROES_MATCH, RTC_ROAP_HIGH);
  RTC_OutCmd(ENABLE);
  RTC_Cmd(ENABLE);
  PWRCU_WakeupPinCmd(ENABLE);
}

/*********************************************************************************************************//**
 * @brief Configures the ADC.
 * @retval None
 ************************************************************************************************************/
void ADC_Configuration(void)
{
    /* Enable peripheral clock of ADC */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.ADC        = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_6, AFIO_FUN_ADC);

  /* ADC configuration ------------------------------------------------------*/
  /* ADC configured as follow:
        - ConversionMode = ONE_SHOT_MODE
        - TriggerMode = SOFTWAER_TRIGGER
  */
  /* Config ADC clock : 8 MHz */
  CKCU_SetADCPrescaler(CKCU_ADCPRE_DIV1);
  ADC_RegularGroupConfig(HT_ADC, ONE_SHOT_MODE, 1, 1);
  ADC_RegularTrigConfig(HT_ADC, ADC_TRIG_SOFTWARE);

  /* ADC transforms potentiometer level and send to USART.(Loop) */
  ADC_RegularChannelConfig(HT_ADC, ADC_CH_6, 0);
  ADC_SamplingTimeConfig(HT_ADC, 0);
  ADC_Cmd(HT_ADC, ENABLE);
}

/*********************************************************************************************************//**
  * @brief  All GPIO pins in input mode with disabled schmitt trigger.
  * @retval : None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
  #if HTCFG_PD
  CKCUClock.Bit.PD         = 1;
  #endif
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  /* Configures all pins as GPIO function */
  AFIO_DeInit();
  AFIO_GPxConfig(GPIO_PA,AFIO_PIN_12 | AFIO_PIN_13 , AFIO_MODE_1);
  AFIO_GPxConfig(GPIO_PB,AFIO_PIN_10 | AFIO_PIN_11| AFIO_PIN_13 | AFIO_PIN_14, AFIO_MODE_1);

  /* Configures all GPIO pins in input floating */
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_DIR_IN);
  #if HTCFG_PD
  GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_DIR_IN);
  #endif

  GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #if HTCFG_PD
  GPIO_PullResistorConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #endif

  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_12, GPIO_PR_DOWN);

  /* Disable schmitt trigger of all GPIO pins */
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOB, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_ALL, DISABLE);
  #if HTCFG_PD
  GPIO_InputConfig(HT_GPIOD, GPIO_PIN_ALL, DISABLE);
  #endif

  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_5, GPIO_DIR_OUT);
}

#if (HT32F_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Reports both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
  */

  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
