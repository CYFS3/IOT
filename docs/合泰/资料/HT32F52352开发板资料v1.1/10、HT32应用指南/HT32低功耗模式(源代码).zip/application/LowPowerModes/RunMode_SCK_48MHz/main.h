/*********************************************************************************************************//**
 * @file    LowPowerModes/RunMode/main.h
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   The header file of Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32F5XXXX_MAIN_H
#define __HT32F5XXXX_MAIN_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"

/* Exported types ------------------------------------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------------------------------------*/
extern vu32 gwTimeDisplay;

/* Clock gating : Peripherials selection --------------- */
#define ALL_PERIPHERIALS_ENABLE
//#define ONLY_RTC_ENABLE

/* Frequency selection --------------------------------- */
#define HCLK_48MHz
//#define HCLK_8MHz

///* Using of wait for interrupt ------------------------- */
//#define SLEEP_WFI_ON

/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* __HT32F5XXXX_MAIN_H */
