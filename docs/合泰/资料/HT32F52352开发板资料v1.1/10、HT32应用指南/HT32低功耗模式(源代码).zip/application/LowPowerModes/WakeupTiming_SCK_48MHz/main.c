/*********************************************************************************************************//**
 * @file    LowPowerModes/WakeupTiming/main.c
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "main.h"

/** @addtogroup HT32F5xxxxx_Application_Notes HT32F5xxxx Application Notes
  * @{
  */

/** @addtogroup LowPowerModes Low power modes
  * @{
  */

/** @addtogroup WakeupTiming Wakeup timing
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/* Private define ------------------------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
ErrStatus HSEStartUpStatus;
CKCU_PLLInitTypeDef PLLInit;
uint32_t wRtcCntTmp;

/* Private function prototypes -----------------------------------------------------------------------------*/
void CKCU_Configuration(void);
void BAK_Configuration(void);

/* Private functions ---------------------------------------------------------------------------------------*/
void Delay(u32 nCount) {while(nCount--);}

/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  * @note At this stage the microcontroller clock setting is already configured,
  *       this is done through SystemInit() function which is called from startup
  *       file (startup_ht32f520x.s) before to branch to application main.
  *       To reconfigure the default setting of SystemInit() function, refer to
  *       system_ht32f520x.c file
  ***********************************************************************************************************/
int main(void)
{

#if (HT32F_LIB_DEBUG == 1)
  debug();
#endif

  /* Backup domain related configuration */
  BAK_Configuration();

  /* Clock related configuration */
  CKCU_Configuration();

  while (1)
  {
    wRtcCntTmp = RTC_GetCounter();
    while(RTC_GetCounter() == wRtcCntTmp);
    wRtcCntTmp = RTC_GetCounter();
    while(RTC_GetCounter() < (wRtcCntTmp + 10));

    RTC_SetCompare(RTC_GetCounter() + 4096);

    /* Read to clear RTC flags */
    RTC_GetFlagStatus();

    /* Read to clear RTCOUT Level mode flag */
    RTC_GetOutStatus();
    HT_GPIOA->RR = GPIO_PIN_5;

/********************************* SLEEP MODE *********************************/
#ifdef SLEEP
    PWRCU_Sleep(PWRCU_SLEEP_ENTRY_WFE);
#endif /* End of SLEEP test */

/***************************** DEEP SLEEP MODE 1 ******************************/
#ifdef DEEP_SLEEP_1
    PWRCU_DeepSleep1(PWRCU_SLEEP_ENTRY_WFE);
#endif /* End of DEEP SLEEP 1 test */

/***************************** DEEP SLEEP MODE 2 ******************************/
#ifdef DEEP_SLEEP_2
    PWRCU_DeepSleep2(PWRCU_SLEEP_ENTRY_WFE);
#endif /* End of DEEP SLEEP 2 test */

    HT_GPIOA->SRR = GPIO_PIN_5;
  }
}

/*********************************************************************************************************//**
  * @brief  Configures the Clock Control Unit.
  * @retval : None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{

#ifdef HCLK_HSE
  /* Enable HSE */
  CKCU_HSECmd(ENABLE);

  /* Wait till HSE is ready */
  HSEStartUpStatus = CKCU_WaitHSEReady();
  if(HSEStartUpStatus != SUCCESS)
  {
    while(1);
  }

  /* Select HSE as system clock source */
  CKCU_SysClockConfig(CKCU_SW_HSE);
#endif /* HCLK_HSE */

#ifdef HCLK_HSE_PLL
  /* Enable HSE */
  CKCU_HSECmd(ENABLE);

  /* Wait till HSE is ready */
  HSEStartUpStatus = CKCU_WaitHSEReady();
  if(HSEStartUpStatus != SUCCESS)
  {
    while(1);
  }

  FLASH_SetWaitState(FLASH_WAITSTATE_1);

  /* PLL configuration, PLLCLK = 48MHz */
  PLLInit.ClockSource = CKCU_PLLSRC_HSE;
  PLLInit.BYPASSCmd = DISABLE;
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  PLLInit.CFG = CKCU_PLL_8M_48M;
  CKCU_PLLInit(&PLLInit);
  CKCU_PLLCmd(ENABLE);

  /* Wait until PLL is ready */
  while (CKCU_GetClockReadyStatus(CKCU_FLAG_PLLRDY) == RESET);

  /* Select PLL as system clock source */
  CKCU_SysClockConfig(CKCU_SW_PLL);

  /* Disable HSI */
  CKCU_HSICmd(DISABLE);
#endif /* HCLK_HSE_PLL */

#ifdef HCLK_HSI_PLL
  FLASH_SetWaitState(FLASH_WAITSTATE_1);

  /* PLL configuration, PLLCLK = 48MHz */
  PLLInit.ClockSource = CKCU_PLLSRC_HSI;
  PLLInit.BYPASSCmd = DISABLE;
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  PLLInit.CFG = CKCU_PLL_8M_48M;
  CKCU_PLLInit(&PLLInit);
  CKCU_PLLCmd(ENABLE);

  /* Wait until PLL is ready */
  while (CKCU_GetClockReadyStatus(CKCU_FLAG_PLLRDY) == RESET);

  /* Select PLL as system clock source */
  CKCU_SysClockConfig(CKCU_SW_PLL);
#endif /* HCLK_HSI_PLL */

#ifdef HCLK_HSI
  CKCU_HSECmd(DISABLE);
  CKCU_SysClockConfig(CKCU_SW_HSI);
#endif /* HCLK_HSI */
}

/*********************************************************************************************************//**
 * @brief Configures the Backup Domain.
 * @retval None
 ************************************************************************************************************/
void BAK_Configuration(void)
{
 #ifndef USE_HT32F52230_SK
  /* Check the backup domain(RTC & PWRCU) is ready for access                                               */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.BKP          = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
  if(PWRCU_CheckReadyAccessed() != PWRCU_OK)
  {
    while(1);
  }

  /* Configure Low Speed Internal clock */
  RTC_LSILoadTrimData();
  while(CKCU_GetClockReadyStatus(CKCU_FLAG_LSIRDY) == RESET);

  /* Configure the RTC */
  RTC_ClockSourceConfig(RTC_SRC_LSI) ;
  RTC_SetPrescaler(RTC_RPRE_8);
  RTC_SetCompare(0xFFFFFFFF);
  RTC_Cmd(ENABLE);
  RTC_WakeupConfig(RTC_WAKEUP_CM, ENABLE);

  RTC_OutConfig(RTC_ROWM_LEVEL, RTC_ROES_MATCH, RTC_ROAP_HIGH);
  RTC_OutCmd(ENABLE);
  RTC_GetOutStatus();
  PWRCU_WakeupPinCmd(ENABLE);
#endif
}

#if (HT32F_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Reports both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
  */

  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

