/*********************************************************************************************************//**
 * @file    LowPowerModes/CurrentMeasurements/main.h
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   The header file of Main program.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32F5XXXX_MAIN_H
#define __HT32F5XXXX_MAIN_H



#ifdef __cplusplus
 extern "C" {
#endif



/* Exported types ------------------------------------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------------------------------------*/

/* Define the clock settings */
//#define HSE_PLL_ON
//#define HSE_PLL_ON_48MHz
//#define HSE_PLL_ON_24MHz
//#define HSE_PLL_ON_12MHz

//#define HSE_PLL_OFF
//#define HSE_PLL_OFF_8MHz
//#define HSE_PLL_OFF_1MHz

//#define HSI_PLL_ON
//#define HSI_PLL_ON_48MHz
//#define HSI_PLL_ON_24MHz
//#define HSI_PLL_ON_12MHz

//#define HSI_PLL_OFF
//#define HSI_PLL_OFF_8MHz
//#define HSI_PLL_OFF_1MHz

/* Define the Low power mode*/
//#define SLEEP
//#define DEEP_SLEEP_1
//#define DEEP_SLEEP_2
#define POWER_DOWN


/* Define the clock gating selection of peripherals in Sleep mode */
//#define SLEEP_ALLPERIPH_ENABLE
#define SLEEP_ALLPERIPH_DISABLE

///* Define the FMC clock gating selection in Sleep mode */
//#define SLEEP_FMC_ENABLE
#define SLEEP_FMC_DISABLE

/* Define the SRAM clock gating selection in Sleep mode */
//#define SLEEP_SRAM_ENABLE
#define SLEEP_SRAM_DISABLE

/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif  /* __HT32F5XXXX_MAIN_H */
