/*********************************************************************************************************//**
 * @file    LowPowerModes/RunMode/main.c
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "main.h"

/** @addtogroup HT32F523xx_Application_Notes HT32F5xxxx Application Notes
  * @{
  */

/** @addtogroup LowPowerModes Low power modes
  * @{
  */

/** @addtogroup RunMode Run mode
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/* Private define ------------------------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
CKCU_PLLInitTypeDef PLLInit;
vu32 gwTimeDisplay = 0;

/* Private function prototypes -----------------------------------------------------------------------------*/
void CKCU_Configuration(void);
void RTC_Configuration(void);
void All_GPIO_IN_TriggerOff(void);
u32 Time_Regulate(void);
void Time_Display(u32 wTimeVar);
u32 ScanUnsignedDecimal(void);
void All_PeriphClockConfigENABLE(void);
void All_PeriphClockConfigDISABLE(void);

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{

#if (HT32F_LIB_DEBUG == 1)
  debug();
#endif

  /* Enable RTC PCLK and waits until it's can be access */
  /* Check the backup domain(RTC & PWRCU) is ready for access                                               */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.BKP          = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
  if(PWRCU_CheckReadyAccessed() != PWRCU_OK)
  {
    while(1);
  }

  /* Clock relate configuration */
  CKCU_Configuration();

  /* All GPIO pins in input mode with disabled schmitt trigger */
  All_GPIO_IN_TriggerOff();

  /* Retarget Related configuration */
  RETARGET_Configuration();

  /* Enable NVIC RTC interrupt */
  NVIC_EnableIRQ(RTC_IRQn);

  /* Check if the Power On Reset flag is set */
  if(PWRCU_GetFlagStatus() == PWRCU_FLAG_PWRPOR)
  {
    printf("\r\n\n Power On Reset occurred....");
  }

  if(PWRCU_ReadBackupRegister(PWRCU_BAKREG_0) != 0xA5A5)
  {
    u32 wInitTime = 0;
    /* Backup data register value is not correct or not yet programmed (when
       the first time the program is executed) */

    printf("\r\n\n RTC not yet configured....");

    /* RTC Configuration */
    RTC_Configuration();

    printf("\r\n RTC configured....");

    /* Adjust time by values entred by the user on the hyperterminal,
       Then store the init time to PWRCU_BAKREG_1. */
    wInitTime = Time_Regulate() ;
    PWRCU_WriteBackupRegister(PWRCU_BAKREG_1, wInitTime);

    /* Reset RTC Counter when Time is 23:59:59 */
    RTC_SetCompare(86400 - wInitTime) ;

    PWRCU_WriteBackupRegister(PWRCU_BAKREG_0, 0xA5A5);
    /* Enable RTC */
    RTC_Cmd(ENABLE) ;
  }
  else
  {
    printf("\r\n No need to configure RTC....");
  }

  /* Display current time in infinite loop */
  printf("\n\r");

    All_PeriphClockConfigDISABLE();

#ifdef ALL_PERIPHERIALS_ENABLE
    All_PeriphClockConfigENABLE();
#endif

#ifdef ONLY_RTC_ENABLE
  CKCUClock.Bit.BKP          = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
#endif

  while (1)
  {
    /* If 1s has paased */
    if(gwTimeDisplay == 1)
    {
      /* Display current time.
         Current time is sum of the RTC counter value and the init time(stored in PWRCU_BAKREG_1 register).
         The init time (PWRCU_BAKREG_1 register) will be clear if the RTC Match flag(CMFLAG) is set.
         Refer to RTC_IRQHandler. */
#ifdef ONLY_RTC_ENABLE
      CKCUClock.Bit.USART0          = 1;
      CKCU_PeripClockConfig(CKCUClock, ENABLE);
#endif

      Time_Display(RTC_GetCounter() + PWRCU_ReadBackupRegister(PWRCU_BAKREG_1));

#ifdef ONLY_RTC_ENABLE
      CKCUClock.Bit.USART1          = 1;
      CKCU_PeripClockConfig(CKCUClock, ENABLE);
#endif
      gwTimeDisplay = 0;
    }

#ifdef SLEEP_WFI_ON
    PWRCU_Sleep(PWRCU_SLEEP_ENTRY_WFI);
#endif
  }
}

/*********************************************************************************************************//**
  * @brief  Configures the Clock Control Unit.
  * @retval : None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
#ifdef HCLK_48MHz

  /* Set the Flash wait states */
  FLASH_SetWaitState(FLASH_WAITSTATE_1);

  /* PLL configuration, PLLCLK = 48MHz */
  PLLInit.ClockSource = CKCU_PLLSRC_HSI;
  PLLInit.BYPASSCmd = DISABLE;
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  PLLInit.CFG = CKCU_PLL_8M_48M;

  /* Enable PLL */
  CKCU_PLLInit(&PLLInit);
  CKCU_PLLCmd(ENABLE);

  /* Wait until PLL is ready */
  while (CKCU_GetClockReadyStatus(CKCU_FLAG_PLLRDY) == RESET);

  /* Select PLL as system clock source */
  CKCU_SysClockConfig(CKCU_SW_PLL);
#endif /* HCLK_48MHz */

#ifdef HCLK_8MHz
 CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  CKCU_SysClockConfig(CKCU_SW_HSI);
#endif /* HCLK_8MHz */
  CKCU_SleepClockConfig(CKCU_AHBEN_SLEEP_FMC | CKCU_AHBEN_SLEEP_SRAM, DISABLE);

}

/*********************************************************************************************************//**
  * @brief  Enable the clock of all APB peripheral.
  * @retval : None
  ***********************************************************************************************************/
void All_PeriphClockConfigENABLE()
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.PDMA       = 1;
  CKCUClock.Bit.USBD       = 1;
  CKCUClock.Bit.CKREF      = 1;
  CKCUClock.Bit.EBI        = 1;
  CKCUClock.Bit.CRC        = 1;
  CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
  CKCUClock.Bit.PD         = 1;
  CKCUClock.Bit.I2C0       = 1;
  CKCUClock.Bit.I2C1       = 1;
  CKCUClock.Bit.SPI0       = 1;
  CKCUClock.Bit.SPI1       = 1;
  CKCUClock.Bit.USART0     = 1;
  CKCUClock.Bit.USART1     = 1;
  CKCUClock.Bit.UART0      = 1;
  CKCUClock.Bit.UART1      = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.EXTI       = 1;
  CKCUClock.Bit.SCI0       = 1;
  CKCUClock.Bit.SCI1       = 1;
  CKCUClock.Bit.I2S        = 1;
  CKCUClock.Bit.MCTM0      = 1;
  CKCUClock.Bit.WDT        = 1;
  CKCUClock.Bit.BKP        = 1;
  CKCUClock.Bit.GPTM0      = 1;
  CKCUClock.Bit.GPTM1      = 1;
  CKCUClock.Bit.BFTM0      = 1;
  CKCUClock.Bit.BFTM1      = 1;
  CKCUClock.Bit.CMP        = 1;
  CKCUClock.Bit.ADC        = 1;
  CKCUClock.Bit.SCTM0      = 1;
  CKCUClock.Bit.SCTM1      = 1;
  CKCUClock.Bit.SCTM2      = 1;
  CKCUClock.Bit.SCTM3      = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}
/*********************************************************************************************************//**
  * @brief  Disable the clock of all APB peripheral.
  * @retval : None
  ***********************************************************************************************************/
void All_PeriphClockConfigDISABLE()
{
   CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCU_PeripClockConfig(CKCUClock, DISABLE);
}
/*********************************************************************************************************//**
  * @brief  All GPIO pins in input mode with disabled schmitt trigger.
  * @retval : None
  ***********************************************************************************************************/
void All_GPIO_IN_TriggerOff(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
  #if HTCFG_PD
  CKCUClock.Bit.PD         = 1;
  #endif
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  /* Configures all pins as GPIO function */
  AFIO_DeInit();
  AFIO_GPxConfig(GPIO_PA,AFIO_PIN_12 | AFIO_PIN_13 , AFIO_MODE_1);
  AFIO_GPxConfig(GPIO_PB,AFIO_PIN_10 | AFIO_PIN_11 | AFIO_PIN_12| AFIO_PIN_13 | AFIO_PIN_14, AFIO_MODE_1);

  /* Configures all GPIO pins in input floating */
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_DIR_IN);
  #if HTCFG_PD
  GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_DIR_IN);
  #endif

  GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #if HTCFG_PD
  GPIO_PullResistorConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #endif

  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_12, GPIO_PR_DOWN);

  /* Disable schmitt trigger of all GPIO pins */
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOB, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_ALL, DISABLE);
  #if HTCFG_PD
  GPIO_InputConfig(HT_GPIOD, GPIO_PIN_ALL, DISABLE);
  #endif
}


/*********************************************************************************************************//**
 * @brief Configures the RTC.
 * @retval None
 * @details RTC configuration as following:
 *  - S/W reset backup domain.
 *  - Configure Low Speed External clock (LSI).
 *    - Enable the LSI.
 *    - Waits till LSI is ready.
 *  - Configure RTC.
 *    - Select LSI as RTC Clock Source.
 *    - Enable the RTC Second interrupt.
 *    - RTC prescaler = 32768 to generate 1 second interrupt.
 *    - Enable clear RTC counter by match function.
 *
 ************************************************************************************************************/
void RTC_Configuration(void)
{
  /* Reset Backup Domain */
  PWRCU_DeInit();

  /* Configure Low Speed External clock (LSI) */
  RTC_LSICmd(ENABLE);
  while(CKCU_GetClockReadyStatus(CKCU_FLAG_LSIRDY) == RESET);

  /* Configure the RTC */
  RTC_ClockSourceConfig(RTC_SRC_LSI) ;
  RTC_IntConfig(RTC_INT_CSEC, ENABLE);
  RTC_SetPrescaler(RTC_RPRE_32768);

  /* Restart counter when match event occured */
  RTC_CMPCLRCmd(ENABLE) ;
}

/*********************************************************************************************************//**
  * @brief  Returns the time entered by user, using Hyperterminal.
  * @return Enter time, unit is second within a day.
  ***********************************************************************************************************/
u32 Time_Regulate(void)
{
  u32 Tmp_HH = 0xFF, Tmp_MM = 0xFF, Tmp_SS = 0xFF;

  printf("\r\n==============Time Settings=====================================");
  printf("\r\n  Please Set Hours");
  do
  {
    Tmp_HH = ScanUnsignedDecimal();
  } while(Tmp_HH > 23) ;
  printf(":  %u", (unsigned int)Tmp_HH);

  printf("\r\n  Please Set Minutes");
  do
  {
    Tmp_MM = ScanUnsignedDecimal();
  } while(Tmp_MM > 59) ;
  printf(":  %u", (unsigned int)Tmp_MM);

  printf("\r\n  Please Set Seconds");
  do
  {
    Tmp_SS = ScanUnsignedDecimal();
  } while(Tmp_SS > 59) ;
  printf(":  %u", (unsigned int)Tmp_SS);

  return((Tmp_HH*3600 + Tmp_MM*60 + Tmp_SS));
}

/*********************************************************************************************************//**
  * @brief  Displays the input time.
  * @param  wTimeVar: Displays time.
  * @retval None
  ***********************************************************************************************************/
void Time_Display(u32 wTimeVar)
{
  u32 THH = 0, TMM = 0, TSS = 0;

  /* Compute  hours */
  THH = wTimeVar/3600;
  /* Compute minutes */
  TMM = (wTimeVar % 3600)/60;
  /* Compute seconds */
  TSS = (wTimeVar % 3600)% 60;

  printf("Time: %02u:%02u:%02u\r",(unsigned int)THH, (unsigned int)TMM, (unsigned int)TSS);
}

/*********************************************************************************************************//**
  * @brief  Scan an unsigned decimal number.
  * @return An unsigned decimal value.
  ***********************************************************************************************************/
u32 ScanUnsignedDecimal(void)
{
  u8 bChar=0;
  u32 wNbr=0;
  while(1)
  {
    bChar = getchar();
    if((bChar >= '0') && (bChar <= '9'))
    {
      wNbr = (wNbr * 10) + (bChar - '0');
    }
    else
    {
      break;
    }

  }
  return wNbr;
}

#if (HT32F_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Reports both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
  */

  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
