/*********************************************************************************************************//**
 * @file    LowPowerModes/WakeupTiming/main.h
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   The header file of Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32F5XXXX_MAIN_H
#define __HT32F5XXXX_MAIN_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"

/* Exported types ------------------------------------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------------------------------------*/

/* Define the Low power mode*/
//#define SLEEP
//#define DEEP_SLEEP_1
#define DEEP_SLEEP_2

/* Define the system clock */
#define HCLK_HSI
////#define HCLK_HSI_PLL
//#define HCLK_HSE
//#define HCLK_HSE_PLL

/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* __HT32F5XXXX_MAIN_H */
