/*********************************************************************************************************//**
 * @file    LowPowerModes/CurrentMeasurements/main.c
 * @version $Rev:: 2157         $
 * @date    $Date:: 2017-11-23 #$
 * @brief   Main program.
 *************************************************************************************************************
 *
 * <h2><center>Copyright (C) 2017 Holtek Semiconductor Inc. All rights reserved</center></h2>
 *
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "main.h"

/** @addtogroup HT32F5xxxx_Application_Notes HT32F5xxxx Application Notes
  * @{
  */

/** @addtogroup LowPowerModes Low power modes
  * @{
  */

/** @addtogroup CurrentMeasurements Current measurements
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/* Private define ------------------------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
ErrStatus HSEStartUpStatus;
CKCU_PLLInitTypeDef PLLInit;

/* Private function prototypes -----------------------------------------------------------------------------*/
void RTC_Configuration(void);
void CKCU_Configuration(void);
void NVIC_Configuration(void);
void All_GPIO_IN_TriggerOff(void);
void All_PeriphClockConfigENABLE(void);
void All_PeriphClockConfigDISABLE(void);
void WakeupPinConfiguration(void);

/* Private functions ---------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Inserts a delay time.
  * @param nCount: specifies the delay time length.
  * @retval : None
  ***********************************************************************************************************/
void Delay(__IO uint32_t nCount)  {while(nCount--);}

/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
#if (HT32F_LIB_DEBUG == 1)
  debug();
#endif

  /* RTC related configuration */
  RTC_Configuration();

  /* Clock related configuration */
  CKCU_Configuration();

  /* All GPIO pins in input mode with disabled schmitt trigger */
  All_GPIO_IN_TriggerOff();

/****************************** SLEEP MODE ****************************************/
#ifdef SLEEP

#ifdef SLEEP_ALLPERIPH_ENABLE
  All_PeriphClockConfigENABLE();
#endif

#ifdef SLEEP_ALLPERIPH_DISABLE
  All_PeriphClockConfigDISABLE();
#endif

#ifdef SLEEP_FMC_ENABLE
  CKCU_SleepClockConfig(CKCU_AHBEN_SLEEP_FMC, ENABLE);
#endif

#ifdef SLEEP_FMC_DISABLE
  CKCU_SleepClockConfig(CKCU_AHBEN_SLEEP_FMC, DISABLE);
#endif

#ifdef SLEEP_SRAM_ENABLE
  CKCU_SleepClockConfig(CKCU_AHBEN_SLEEP_SRAM, ENABLE);
#endif

#ifdef SLEEP_SRAM_DISABLE
  CKCU_SleepClockConfig(CKCU_AHBEN_SLEEP_SRAM, DISABLE);
#endif

  /* Mode: SLEEP + Entry with WFE*/
  __WFE();

#endif /* End of SLEEP test */


/*************************** DEEP SLEEP MODE 1 ************************************/
#ifdef DEEP_SLEEP_1
  /* Request to enter Deep Sleep mode 1 (VDD15 use LDO in low power mode) */
  PWRCU_DeepSleep1(PWRCU_SLEEP_ENTRY_WFE);
#endif /* End of DEEP SLEEP 1 test */

/*************************** DEEP SLEEP MODE 2 ************************************/
#ifdef DEEP_SLEEP_2
  /* Request to enter Deep Sleep mode 2 (VDD15 use DMOS) */
  PWRCU_DeepSleep2(PWRCU_SLEEP_ENTRY_WFE);
#endif /* End of DEEP SLEEP 2 test */

/**************************** POWER DOWN MODE *************************************/
#ifdef POWER_DOWN
  PWRCU_PowerDown();
#endif /* End of POWER DOWN MODE test */

  /* Infinite loop */
  while(1)
  {
  }
}

/*********************************************************************************************************//**
  * @brief  Configures the Clock Control Unit.
  * @param  None
  * @retval : None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
#ifdef HSE_PLL_ON
  /* Enable HSE */
  CKCU_HSECmd(ENABLE);

  /* Wait till HSE is ready */
  HSEStartUpStatus = CKCU_WaitHSEReady();
  if(HSEStartUpStatus != SUCCESS)
  {
    while(1);
  }

  /* Set the Flash wait states */
  #ifdef HSE_PLL_ON_48MHz /* 1 wait states */
  FLASH_SetWaitState(FLASH_WAITSTATE_1);
  #endif

  /* PLL configuration, PLLCLK = 48MHz */
  PLLInit.ClockSource = CKCU_PLLSRC_HSE;
  PLLInit.BYPASSCmd = DISABLE;
  PLLInit.CFG = CKCU_PLL_8M_48M;

  #ifdef HSE_PLL_ON_48MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  #endif

  #ifdef HSE_PLL_ON_24MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV2);
  #endif

  #ifdef HSE_PLL_ON_12MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV4);
  #endif

  /* Enable PLL */
  CKCU_PLLInit(&PLLInit);
  CKCU_PLLCmd(ENABLE);

  /* Wait until PLL is ready */
  while (CKCU_GetClockReadyStatus(CKCU_FLAG_PLLRDY) == RESET);

  /* Select PLL as system clock source */
  CKCU_SysClockConfig(CKCU_SW_PLL);

  /* Disable HSI */
  CKCU_HSICmd(DISABLE);
#endif /* HSE_PLL_ON */

#ifdef HSE_PLL_OFF

  /* Enable HSE */
  CKCU_HSECmd(ENABLE);

  /* Wait till HSE is ready */
  HSEStartUpStatus = CKCU_WaitHSEReady();
  if(HSEStartUpStatus != SUCCESS)
  {
    while(1);
  }

  #ifdef HSE_PLL_OFF_8MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  #endif

  #ifdef HSE_PLL_OFF_1MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV8);
  #endif

  /* Select HSE as system clock source */
  CKCU_SysClockConfig(CKCU_SW_HSE);

  /* Disable HSI */
  CKCU_HSICmd(DISABLE);
#endif /* HSE_PLL_OFF */

#ifdef HSI_PLL_ON

  /* Set the Flash wait states */
  #ifdef HSI_PLL_ON_48MHz /* 1 wait states */
  FLASH_SetWaitState(FLASH_WAITSTATE_1);
  #endif


  /* PLL configuration, PLLCLK = 48MHz */
  PLLInit.ClockSource = CKCU_PLLSRC_HSI;
  PLLInit.BYPASSCmd = DISABLE;
  PLLInit.CFG =  CKCU_PLL_8M_48M;

  #ifdef HSI_PLL_ON_48MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  #endif

  #ifdef HSI_PLL_ON_24MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV2);
  #endif

  #ifdef HSI_PLL_ON_12MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV4);
  #endif

  /* Enable PLL */
  CKCU_PLLInit(&PLLInit);
  CKCU_PLLCmd(ENABLE);

  /* Wait until PLL is ready */
  while (CKCU_GetClockReadyStatus(CKCU_FLAG_PLLRDY) == RESET);

  /* Select PLL as system clock source */
  CKCU_SysClockConfig(CKCU_SW_PLL);
#endif /* HSI_PLL_ON */

#ifdef HSI_PLL_OFF

  #ifdef HSI_PLL_OFF_8MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV1);
  #endif

  #ifdef HSI_PLL_OFF_1MHz
  CKCU_SetHCLKPrescaler(CKCU_SYSCLK_DIV8);
  #endif
    CKCU_SysClockConfig(CKCU_SW_HSI);
#endif /* HSI_PLL_OFF */

}

/*********************************************************************************************************//**
  * @brief  Enable the clock of all APB peripheral.
  * @retval : None
  ***********************************************************************************************************/
void All_PeriphClockConfigENABLE()
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.PDMA       = 1;
  CKCUClock.Bit.USBD       = 1;
  CKCUClock.Bit.CKREF      = 1;
  CKCUClock.Bit.EBI        = 1;
  CKCUClock.Bit.CRC        = 1;
  CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
  CKCUClock.Bit.PD         = 1;
  CKCUClock.Bit.I2C0       = 1;
  CKCUClock.Bit.I2C1       = 1;
  CKCUClock.Bit.SPI0       = 1;
  CKCUClock.Bit.SPI1       = 1;
  CKCUClock.Bit.USART0     = 1;
  CKCUClock.Bit.USART1     = 1;
  CKCUClock.Bit.UART0      = 1;
  CKCUClock.Bit.UART1      = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.EXTI       = 1;
  CKCUClock.Bit.SCI0       = 1;
  CKCUClock.Bit.SCI1       = 1;
  CKCUClock.Bit.I2S        = 1;
  CKCUClock.Bit.MCTM0      = 1;
  CKCUClock.Bit.WDT        = 1;
  CKCUClock.Bit.BKP        = 1;
  CKCUClock.Bit.GPTM0      = 1;
  CKCUClock.Bit.GPTM1      = 1;
  CKCUClock.Bit.BFTM0      = 1;
  CKCUClock.Bit.BFTM1      = 1;
  CKCUClock.Bit.CMP        = 1;
  CKCUClock.Bit.ADC        = 1;
  CKCUClock.Bit.SCTM0      = 1;
  CKCUClock.Bit.SCTM1      = 1;
  CKCUClock.Bit.SCTM2      = 1;
  CKCUClock.Bit.SCTM3      = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}
/*********************************************************************************************************//**
  * @brief  Disable the clock of all APB peripheral.
  * @retval : None
  ***********************************************************************************************************/
void All_PeriphClockConfigDISABLE()
{
   CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCU_PeripClockConfig(CKCUClock, DISABLE);
}
/*********************************************************************************************************//**
  * @brief  All GPIO pins in input mode with disabled schmitt trigger.
  * @retval : None
  ***********************************************************************************************************/
void All_GPIO_IN_TriggerOff(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
  #if HTCFG_PD
  CKCUClock.Bit.PD         = 1;
  #endif
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  /* Configures all pins as GPIO function */
  AFIO_DeInit();
  AFIO_GPxConfig(GPIO_PA,AFIO_PIN_12 | AFIO_PIN_13 , AFIO_MODE_1);
  AFIO_GPxConfig(GPIO_PB,AFIO_PIN_10 | AFIO_PIN_11 | AFIO_PIN_12| AFIO_PIN_13 | AFIO_PIN_14, AFIO_MODE_1);

  /* Configures all GPIO pins in input floating */
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_DIR_IN);
  #if HTCFG_PD
  GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_DIR_IN);
  #endif

  GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #if HTCFG_PD
  GPIO_PullResistorConfig(HT_GPIOD, GPIO_PIN_ALL, GPIO_PR_DISABLE);
  #endif

  GPIO_PullResistorConfig(HT_GPIOB, GPIO_PIN_12, GPIO_PR_DOWN);

  /* Disable schmitt trigger of all GPIO pins */
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOB, GPIO_PIN_ALL, DISABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_ALL, DISABLE);
  #if HTCFG_PD
  GPIO_InputConfig(HT_GPIOD, GPIO_PIN_ALL, DISABLE);
  #endif
}

/*********************************************************************************************************//**
  * @brief  Configures RTC clock source and prescaler.
  * @retval None
  * @details The RTC configuration as following
  ***********************************************************************************************************/
void RTC_Configuration(void)
{
#ifndef USE_HT32F52230_SK
  /* Check the backup domain(RTC & PWRCU) is ready for access                                               */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.BKP          = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  if (PWRCU_CheckReadyAccessed() != PWRCU_OK)
  {
    while (1);
  }
  /* Load trim data of Low Speed Internal clock (LSI) */
  RTC_LSILoadTrimData();
  RTC_LSICmd(ENABLE);
  while(CKCU_GetClockReadyStatus(CKCU_FLAG_LSIRDY) == RESET);
  RTC_ClockSourceConfig(RTC_SRC_LSI);
  /* Configure the RTC */
  RTC_SetPrescaler(RTC_RPRE_8);

  /* Enable RTC counter */
  RTC_Cmd(ENABLE) ;

  PWRCU_WakeupPinCmd(ENABLE);
#endif
}

#if (HT32F_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Reports both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
  */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
